Name: Jiayi Qi
NetID: jqi8
All works are finished by myself.
The basic TTT is basicTTT_stdinout.py.
The 9 Board TTT is advancedTTT.py.
The Ultimate 9 Board TTT is MoreadvancedTTT.py.

All you need to do is to use the command: python3 filename.py